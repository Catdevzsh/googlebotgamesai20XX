
import pygame
import random

pygame.init()
screen = pygame.display.set_mode((800,600))  
clock = pygame.time.Clock()

pad_w = 20  
pad_h = 100  
pad_vy = 5  

ball_r = 10
ball_x = 400; ball_y = 300  
ball_vx = 5; ball_vy = 5  

player1_y = 250
player2_y = 250

player1_score = 0   
player2_score = 0

font = pygame.font.Font(None, 72)

def draw_text(text, x, y):  
    label = font.render(text, True, (255,255,255)) 
    screen.blit(label, (x, y))

def draw_rect(x, y, w, h, color):  
    pygame.draw.rect(screen, color, (x, y, w, h))  

running = True  
while running: 
    clock.tick(60)  

    for event in pygame.event.get():
        if event.type == pygame.QUIT:     
            running = False  

    keys = pygame.key.get_pressed()

    if keys[pygame.K_w] and player1_y > pad_h//2:  
        player1_y -= pad_vy  
    if keys[pygame.K_s] and player1_y < 600 - pad_h // 2:   
        player1_y += pad_vy  

    if keys[pygame.K_UP] and player2_y > pad_h//2:      
        player2_y -= pad_vy  
    if keys[pygame.K_DOWN] and player2_y < 600 - pad_h//2:    
        player2_y += pad_vy  

    screen.fill((0,0,0))

    draw_rect(0, player1_y, pad_w, pad_h, (255,255,255)) 
    draw_rect(780, player2_y, pad_w, pad_h, (255,255,255))  

    ball_x += ball_vx 
    ball_y += ball_vy

    if ball_x <= pad_w + ball_r:   
        if (ball_y >= player1_y and 
            ball_y <= player1_y + pad_h):  
            ball_vx = -ball_vx             
        else:        
            player2_score += 1       
            ball_x, ball_y = 400, 300        
            ball_vx, ball_vy = 5, 5    

    if ball_x >= 800 - pad_w - ball_r:  
        if (ball_y >= player2_y and        
            ball_y <= player2_y + pad_h):     
            ball_vx = -ball_vx              
        else:        
            player1_score += 1        
            ball_x, ball_y = 400, 300         
            ball_vx, ball_vy = -5, 5   

    if ball_y <= ball_r:              
        ball_vy = -ball_vy             

    if ball_y >= 600 - ball_r:         
        ball_vy = -ball_vy              

    pygame.draw.circle(screen, (255,255,255), (ball_x, ball_y), ball_r)

    draw_text(str(player1_score), 100, 20) 
    draw_text(str(player2_score), 700, 20)

    pygame.display.flip()   

print("Final Score:")  
print(f"Player 1: {player1_score}")
print(f"Player 2: {player2_score}") 
pygame.quit()
